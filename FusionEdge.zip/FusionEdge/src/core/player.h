#pragma once
#include "options.h"
#include "../audioI2S/Audio.h"

#ifndef MQTT_BURL_SIZE
  #define MQTT_BURL_SIZE 512
#endif

#ifndef PLQ_SEND_DELAY
  #define PLQ_SEND_DELAY 0
#endif
enum playerRequestType_e : uint8_t {
  PR_PLAY = 1,
  PR_STOP = 2,
  PR_PREV = 3,
  PR_NEXT = 4,
  PR_VOL = 5,
  PR_CHECKSD = 6,
  PR_BURL = 8,
  PR_TOGGLE = 9,
  PR_URL = 10
};
struct playerRequestParams_t {
  playerRequestType_e type;
  int payload;
};

enum plStatus_e : uint8_t {
  PLAYING = 1,
  STOPPED = 2
};

class Player : public Audio {
private:
  uint32_t _volTicks; /* delayed volume save  */
  bool _volTimer;     /* delayed volume save  */
  uint32_t    _resumeFilePos;
  plStatus_e _status;
  //char        _plError[PLERR_LN];
private:
  void _stop(bool alreadyStopped = false);
  void _play(uint16_t stationId);
  bool _connectToHostProtected(const char* url);
  void _loadVol();
  int8_t uiToDb(int8_t uiVal);
  bool _hasError;
  volatile bool _transitionInProgress;
  volatile bool _playRequested;
  SemaphoreHandle_t _audioClientMutex;
  // Buffers for PR_URL request
  // (fixed sizes to avoid dependency on BUFLEN macro)
  char _urlBuf[512];
  char _nameBuf[192];

public:
  bool lockOutput = true;
  bool resumeAfterUrl = false;
  volatile bool connproc = true;
  volatile bool acceptStreamMeta = false;
  uint32_t sd_min, sd_max;
#ifdef MQTT_ROOT_TOPIC
  char burl[MQTT_BURL_SIZE]; /* buffer for browseUrl  */
#endif
public:
  Player();
  void init();
  void loop();
  bool connecttospeech(const char* speech, const char* lang);
  void initHeaders(const char *file);
  void setError();
  void setError(const char *e);
  void sendCommand(playerRequestParams_t request);
  void checkAutoStartStop(); /* ----- Auto On-Off Timer ----- */
  void setVolumeCurveDbLut(const float *dbValues, size_t count);
  void setVolumeCurveDbPoint(uint8_t index, float dbValue);
  float getVolumeCurveDbPoint(uint8_t index) const;
  void resetVolumeCurveDbLut();
  bool sendCommandNoWait(playerRequestParams_t request);
  bool readyForWebStation() const;
  bool wantsPlayback() const { return _playRequested; }
  void resetQueue();
#ifdef MQTT_ROOT_TOPIC
  void browseUrl();
#endif
  bool remoteStationName = false;
  plStatus_e status() {
    return _status;
  }
  void prev();
  void next();
  void toggle();
  void stepVol(bool up);
  void setVol(uint8_t volume);
  uint8_t volToI2S(uint8_t volume);
  void setTone(int8_t bass, int8_t mid, int8_t treble);
  void stopInfo();
  // Play arbitrary URL (used by presets). Executed in player task via queue.
  void playUrl(const char *url, const char *name = nullptr);
  void setOutputPins(bool isPlaying);
  void setResumeFilePos(uint32_t pos) { _resumeFilePos = pos; }
};

extern Player player;

extern __attribute__((weak)) void player_on_start_play();
extern __attribute__((weak)) void player_on_stop_play();
extern __attribute__((weak)) void player_on_track_change();
extern __attribute__((weak)) void player_on_station_change();
