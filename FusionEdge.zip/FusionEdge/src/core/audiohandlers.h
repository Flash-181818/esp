#pragma once

#include <Arduino.h>
#include "../audioI2S/Audio.h"
#include "../displays/tools/language.h"
#include "audiohelpers.h"

#ifdef USE_NEXTION
extern decltype(nextion) nextion;  // Nextion kijelző objektum (extern)
#endif

String currentArtist = "";
String currentTitle = "";
uint16_t currentStationId = static_cast<uint16_t>(-1);
bool metaOff = false; 

static bool g_forcePlaylistStationName = false;
static String g_forcedPlaylistStationName = "";

static bool isDotPlaylistStationActive() {
  const char *name = config.station.name;
  if (!name) {
    return false;
  }

  // Új dot-os állomás indult: eltesszük a pont nélküli listás nevet.
  if (name[0] == '.') {
    g_forcePlaylistStationName = true;
    g_forcedPlaylistStationName = String(name + 1);
    return true;
  }

  // Már levágtuk a pontot, de még ugyanaz az állomás aktív.
  if (g_forcePlaylistStationName && g_forcedPlaylistStationName.length() > 0 && g_forcedPlaylistStationName == String(name)) {
    return true;
  }

  // Másik, nem dot-os állomásra váltottunk.
  g_forcePlaylistStationName = false;
  g_forcedPlaylistStationName = "";
  return false;
}

static const char *playlistStationDisplayName() {
  if (g_forcePlaylistStationName && g_forcedPlaylistStationName.length() > 0) {
    return g_forcedPlaylistStationName.c_str();
  }
  if (config.station.name[0] == '.') {
    return config.station.name + 1;
  }
  return config.station.name;
}

void my_audio_info(Audio::msg_t m);
void processID3(const char *msg);
void audio_bitrate(const char *info);
bool printable(const char *info);
void audio_showstation(const char *info);
void audio_showstreamtitle(const char *info);
void audio_error(const char *info);
void audio_id3artist(const char *info);
void audio_setTitleSafe(const char *info);
void audio_icy_description(const char *info);
void audio_beginSDread();
void audio_id3data(const char *info);
void audio_eof();
void audio_progress(uint32_t startpos, uint32_t endpos);
void seekSD();
void removeBOM(char *s);
bool cleanMeta(const char *src, char *dst, size_t dstSize);
void _utf8_clean(char *s);
void normalizeText(char *s);

static void safeStrCopy(char *dst, const char *src, size_t dstSize) {
  if (!dst || !src || dstSize == 0) {
    return;
  }
  strlcpy(dst, src, dstSize);  // biztos null-terminált tesz
}

/* 
 * Ha van esemény, ezt futtatja a Schreibfaul1 audio könyvtár.
 * Profi, event-alapú verzió: elsődlegesen m.e (event_t) alapján dolgozik,
 */
void my_audio_info(Audio::msg_t m) {
  const char *msg = (m.msg != nullptr) ? m.msg : "";

  // Ha a kimenet zárolva, semmit nem frissítünk
  if (player.lockOutput) {
    return;
  }

  // Ha nincs értelmes üzenet, nincs mit feldolgozni
  if (!msg) {
    return;
  }

  if (strstr(msg, "Account already in use") != nullptr || strstr(msg, "HTTP/1.0 401") != nullptr) {
    player.setError(msg);
  }

  if (!player.acceptStreamMeta) {
    return;
  }

  // Ponttal kezdődő állomásnév kezelése:
  // - a kijelzőn/weben maradjon a listában megadott állomásnév a kezdő pont nélkül
  // - de a stream metaadatát NE tiltsuk le, hogy előadó/dalcím mindig megjelenhessen
  const bool forcePlaylistStationName = isDotPlaylistStationActive();
  metaOff = false;

  if (forcePlaylistStationName) {
    const char *displayName = playlistStationDisplayName();
    if (strcmp(config.station.name, displayName) != 0) {
      config.setStation(displayName);
      display.putRequest(NEWSTATION);
      netserver.requestOnChange(STATION, 0);
    }
  }

  // --------------------------------------------------------------------
  // EVENT-ALAPÚ FELDOLGOZÁS (m.e alapján)
  // --------------------------------------------------------------------
  switch (m.e) {

    // ----- Általános információk, formátum, SD hossz stb. -----
    case Audio::evt_info:
    {
      if (config.getMode() == PM_SDCARD && strstr(msg, "Reading file:") != nullptr) {
        currentArtist = "";
        currentTitle = "";
      }

      // Formátum felismerés
      BitrateFormat newFmt = BF_UNKNOWN;
      const bool isMp3Info =
        strstr(msg, "MPEG-1 Layer III") != nullptr ||
        strstr(msg, "MPEG-2 Layer III") != nullptr ||
        strstr(msg, "MPEG-2.5 Layer III") != nullptr ||
        ((strstr(msg, "MPEG") != nullptr || strstr(msg, "mpeg") != nullptr) && strstr(msg, "Layer III") != nullptr) ||
        strstr(msg, "MP3") != nullptr || strstr(msg, "mp3") != nullptr;

      if (isMp3Info) {
        newFmt = BF_MP3;
      } else if (strstr(msg, "AAC") != nullptr) {
        newFmt = BF_AAC;
      } else if (strstr(msg, "FLAC") != nullptr) {
        newFmt = BF_FLAC;
      } else if (strstr(msg, "WAV") != nullptr) {
        newFmt = BF_WAV;
      } else if (strstr(msg, "OGG") != nullptr || strstr(msg, "VORBIS") != nullptr) {
        newFmt = BF_OGG;
      } else if (strstr(msg, "OPUS") != nullptr) {
        newFmt = BF_OPU;
      }

      if (newFmt != BF_UNKNOWN) {
        if (config.configFmt != newFmt) {
          config.setBitrateFormat(newFmt);
          display.putRequest(DBITRATE);
        }
        netserver.requestOnChange(BITRATE, 0);
      }

      // SD mód: "stream ready" → seek a mentett pozícióra
      if (strstr(msg, "stream ready") != nullptr) {
        seekSD();
      }
      // SD mód: Audio-Data-Start
      else if (strstr(msg, "Audio-Data-Start:") != nullptr) {
        player.sd_min = atoi(msg + strlen("Audio-Data-Start:"));
      }
      // SD mód: teljes hossz (Audio-Length:)
      else if (strstr(msg, "Audio-Length:") != nullptr) {
        uint32_t audioLength = static_cast<uint32_t>(atoi(msg + strlen("Audio-Length:")));
        player.sd_max = player.sd_min + audioLength;
        netserver.requestOnChange(SDLEN, 0);  // slider tartomány a web felé
      }

      // Ha a stream „skip metadata” módot jelez, akkor állomásnév kerül a title-be
      if (strstr(msg, "skip metadata") != nullptr) {
        // Csak akkor írjuk ki fallbackként az állomás nevét, ha még nincs title.
        // Így a később/korábban érkező ICY/ID3 metaadatot nem töröljük felül.
        if (strlen(config.station.title) == 0) {
          if (forcePlaylistStationName) {
            config.setTitle(playlistStationDisplayName());
          } else {
            config.setTitle(config.station.name);
          }
        }
      }
    } break;

    // ----- Bitráta esemény -----
    case Audio::evt_bitrate:
    {
      // A könyvtár tipikusan szövegként adja meg a bitrátát (pl. "128000")
      audio_bitrate(msg);
    } break;

      // ----- Stream title (ICY) -----
    case Audio::evt_streamtitle:
    {
      //Serial.println();
      //hexDump("Eredeti: ", msg);
      char metaBuf[BUFLEN];
      if (!metaOff && cleanMeta(msg, metaBuf, sizeof(metaBuf))) {
        audio_setTitleSafe(metaBuf);

      }
      //Serial.println();
      //hexDump("cleanMeta után: ", metaBuf);
    } break;

    // ----- ID3 metaadatok (MP3) -----
    case Audio::evt_id3data:
    {
      audio_id3data(msg);

      // Track számból állomás ID (SD lejátszásnál fontos)
      if (strstr(msg, "Track:") != nullptr) {
        currentStationId = static_cast<uint16_t>(atoi(msg + strlen("Track:")));
      }
      char metaBuf[BUFLEN];
      if (!metaOff && cleanMeta(msg, metaBuf, sizeof(metaBuf))) {
        // processID3 kiszedi az Artist / Title sorokat
        processID3(metaBuf);
      }
    } break;

    // ----- Állomásnév esemény -----
    case Audio::evt_name:
    {
      char metaBuf[BUFLEN];
      if (!forcePlaylistStationName && cleanMeta(msg, metaBuf, sizeof(metaBuf))) {
        config.setStation(metaBuf);
        display.putRequest(NEWSTATION);
        netserver.requestOnChange(STATION, 0);
      } else if (forcePlaylistStationName) {
        config.setStation(playlistStationDisplayName());
        display.putRequest(NEWSTATION);
        netserver.requestOnChange(STATION, 0);
      }
    } break;

    // ----- ICY description (leírás) -----
    case Audio::evt_icydescription:
    {
      if (!metaOff) {
        audio_icy_description(msg);
      }
    } break;

    // ----- ICY URL -----
    case Audio::evt_icyurl:
    {
      // Jelenleg nincs külön feldolgozás, de ha kell, itt bővíthető
      // if (config.store.audioinfo) { ... }
    } break;

    // ----- ICY genre -----
    case Audio::evt_genre:
    {
      // Genre logolása — megjelenítés egyelőre nincs, de Serial-on látszik
      Serial.printf("##AUDIO.GENRE#: %s\n", msg);
    } break;

    // ----- Kép / borító (APIC) -----
    case Audio::evt_image:
    {
      // A msg általában pl.: "APIC found at pos 446"
      // Ha egyszer cover art feldolgozás lesz, az ide kerül.
      // Jelenleg csak logoljuk:
      Serial.printf("##AUDIO.IMG#: %s\n", msg);
    } break;

    // ----- Fájl vége (SD mód) -----
    case Audio::evt_eof:
    {
#ifdef USE_DLNA
      audio_eof();  // TODO Nem mindig érkezik meg az eof.
#endif
    } break;

    // ----- Log események (hiba, diagnosztika) -----
    case Audio::evt_log:
    {
      // Ide jöhetne finomabb log-elemzés, de most az általános
      // hibaszűrést már a switch előtt elintéztük (Account in use / 401).
      // Ha kell, itt tovább bontható.
    } break;

    // ----- Nem használt / újonnan bejövő események -----
    case Audio::evt_lasthost:
    case Audio::evt_icylogo:
    case Audio::evt_lyrics:
    default:
      // Jelenleg nincs külön kezelés, de a debug logban látszik
      break;
  }

  // --------------------------------------------------------------------
  // 2) EXTRA SZÖVEG ALAPÚ ÉRTELMEZÉS (m.msg tartalma alapján),
  //    ami nem szorosan event-típushoz kötött.
  // --------------------------------------------------------------------

  // icy-name: ... → sok rádió ilyen formában küldi a stream állomásnevét.
  // Dot-os playlist névnél ezt szándékosan nem engedjük felülírni.
  if (!forcePlaylistStationName) {
    const char *ici = strstr(msg, "icy-name: ");
    if (ici != nullptr) {
      char icyName[BUFLEN] = {0};
      safeStrCopy(icyName, ici + strlen("icy-name: "), sizeof(icyName));
      char metaBuf[BUFLEN];
      if (cleanMeta(icyName, metaBuf, sizeof(metaBuf)) && strlen(metaBuf) > 0) {
        config.setStation(metaBuf);
        display.putRequest(NEWSTATION);
        netserver.requestOnChange(STATION, 0);
      }
    }
  }
}

/* 
 * Ha megállítottuk a zene lejátszását SD módban és újraindítjuk, 
 * akkor a lejátszás az elejéről kezdődne. 
 * Ha megérkezik a "stream ready" üzenet, akkor vissza kell ugrani
 * a mentett stop pozícióra.
 */
void seekSD() {
  if (config.getMode() == PM_SDCARD && config.sdResumePos > 0) {
    if (currentStationId == config.stopedSdStationId) {
      uint32_t offset = 0;
      if (config.sdResumePos > player.sd_min) {
        offset = config.sdResumePos - player.sd_min;
      }
      player.setAudioFilePosition(offset);
    }
  }
}

void processID3(const char *msg) {
  bool updated = false;
  if (!msg) {
    return;
  }
  // "Artist: " → hossz 8
  if (strstr(msg, "Artist") == msg) {
    String s = String(msg).substring(8);
    s.trim();
    currentArtist = s;
    updated = true;
  }
  // "Title: " → hossz 7
  else if (strstr(msg, "Title") == msg) {
    String s = String(msg).substring(7);
    s.trim();
    currentTitle = s;
    updated = true;
  }
  if (updated) {
    String info;
    if (currentArtist.length() > 0 && currentTitle.length() > 0) {
      info = currentArtist + " - " + currentTitle;
      if (config.getMode() == PM_SDCARD) {
        log_i("##[SDMETA]# artist='%s' title='%s'", currentArtist.c_str(), currentTitle.c_str());
      }
    } else if (currentArtist.length() > 0) {
      info = currentArtist + " -  ";  // cím még nincs
    }
    if (info.length() > 0) {
      config.setTitle(info.c_str());
    }
  }
}

/************************************* */
/*************** BITRATE ***************/
/************************************* */
void audio_bitrate(const char *info) {
  if (!info) {
    return;
  }
  if (config.store.audioinfo) {
    // Itt lehetne plusz log, ha szükséges
  }
  uint32_t br = static_cast<uint32_t>(atoi(info));
  if (br > 3000) {
    br = br / 1000;
  }
  config.station.bitrate = br;
  display.putRequest(DBITRATE);
#ifdef USE_NEXTION
  nextion.bitrate(config.station.bitrate);
#endif
  netserver.requestOnChange(BITRATE, 0);
}

/***************************************/
/*********** PRINTABLE *****************/
/***************************************/
bool printable(const char *info) {
  if (!info) {
    return false;
  }
  const unsigned char *p = reinterpret_cast<const unsigned char *>(info);
  while (*p) {
    unsigned char c = *p;
    // Kontroll karakterek tiltása (0x00–0x1F), TAB opcionálisan engedhető
    if (c < 0x20) {
      if (c != 0x09) {
        return false;
      }
    }
    // ASCII (nyomtatható)
    if (c >= 0x20 && c <= 0x7E) {
      p++;
      continue;
    }
    // UTF-8 multi-byte validálás
    // 2 bájtos
    if ((c & 0xE0) == 0xC0) {
      if ((p[1] & 0xC0) != 0x80) {
        return false;
      }
      p += 2;
      continue;
    }
    // 3 bájtos
    if ((c & 0xF0) == 0xE0) {
      if ((p[1] & 0xC0) != 0x80 || (p[2] & 0xC0) != 0x80) {
        return false;
      }
      p += 3;
      continue;
    }
    // 4 bájtos karakterek tiltása
    if ((c & 0xF8) == 0xF0) {
      return false;
    }
    // Minden más hibás
    return false;
  }
  return true;
}

// Külső meghívásra.
void audio_showstation(const char *info) {
  if (isDotPlaylistStationActive()) {
    config.setStation(playlistStationDisplayName());
    display.putRequest(NEWSTATION);
    netserver.requestOnChange(STATION, 0);
    return;
  }

  bool p = printable(info) && (info && strlen(info) > 0);
  if (player.remoteStationName) {  // MQTT-ről jön
    config.setStation(p ? info : config.station.name);
    display.putRequest(NEWSTATION);
    netserver.requestOnChange(STATION, 0);
  }
}

// Külső meghívásra.
void audio_showstreamtitle(const char *info) {
  if (!info) {
    return;
  }

  if (strstr(info, "Account already in use") != nullptr || strstr(info, "HTTP/1.0 401") != nullptr) {
    player.setError(info);
  }

  bool p = (strlen(info) > 0) && printable(info);

#ifdef DEBUG_TITLES
  config.setTitle(DEBUG_TITLES);
#else
  if (p) {
    config.setTitle(info);
  } else if (strlen(config.station.title) == 0) {
    config.setTitle(config.station.name);
  }
#endif
}

void audio_error(const char *info) {
  if (!info) {
    return;
  }
  player.setError(info);
  Serial.printf("##ERROR#:\t%s\r\n", info);
}

void audio_id3artist(const char *info) {
  if (isDotPlaylistStationActive()) {
    config.setStation(playlistStationDisplayName());
  } else {
    config.setStation(info);
  }
  display.putRequest(NEWSTATION);
  netserver.requestOnChange(STATION, 0);
}

/*
 * config.setTitle() kötőjellel elválasztva kell kapnia Title1 és Title2 sort.
 * Ez hívja a:
 *   netserver.requestOnChange(TITLE, 0); // frissíti a WEB-et
 *   netserver.loop();
 *   display.putRequest(NEWTITLE);
 * Display::_title() szétválasztja a kötőjel mentén a _title1 / _title2 sorokat
 * és frissíti a scrollwidgeteket.
 * 
 * Throttled: avoid excessive NEWTITLE requests in queue.
 */
static char g_lastTitleSent[BUFLEN] = "";
static uint32_t g_lastTitleTime = 0;

void audio_setTitleSafe(const char *info) {
  if (player.lockOutput) {
    return;
  }
  if (!info) {
    return;
  }
  // Throttle: skip if same title sent within last 200ms
  uint32_t now = millis();
  if (strcmp(g_lastTitleSent, info) == 0 && (now - g_lastTitleTime) < 200) {
    return; // Duplicate or too-frequent update, skip
  }
  // New or different title after throttle period
  strlcpy(g_lastTitleSent, info, sizeof(g_lastTitleSent));
  g_lastTitleTime = now;
  config.setTitle(info);
}

void audio_icy_description(const char *info) {
  if (player.lockOutput) {
    return;
  }
  if (!info) {
    return;
  }
  if (strlen(config.station.title) == 0 ||                           // ha üres
      strcmp(config.station.title, config.station.name) == 0 ||      // ha a title megegyezik az állomás nevével
      strstr(config.station.title, "timeout") != nullptr ||          // ha tartalmazza a "timeout" szót
      strcmp_P(config.station.title, LANG::const_PlConnect) == 0) {  // ha title = "[csatlakozás]" (lokalizált)
    config.setTitle(info);
  }
}

void audio_beginSDread() {
  config.setTitle("");
}

void audio_id3data(const char *info) {
  if (player.lockOutput) {
    return;
  }
  if (!info) {
    return;
  }
  Serial.printf("##AUDIO.ID3#: %s\r\n", info);
}

void audio_eof() {
  //Serial.printf("mode=%d (PM_WEB=0, PM_SDCARD=1)\n", config.getMode());
  if (!config.isClockTTS && config.getMode() == PM_SDCARD) {
    config.sdResumePos = 0;
    Serial.println("EOF: SD -> player.next()");
    player.next();
  }

#ifdef USE_DLNA  //DLNA mod
  if (config.store.playlistSource == PL_SRC_DLNA) {
    Serial.println("EOF: DLNA -> player.next()");
    player.next();
    return;
  }
#endif
}

void audio_progress(uint32_t startpos, uint32_t endpos) {
  player.sd_min = startpos;
  player.sd_max = endpos;
  netserver.requestOnChange(SDLEN, 0);
}
// Az audiohelpers.h fájlban van deklarálva.
// Hexadecimális kiiratás debug használatra.
void hexDump(const char *label, const char *s) {
  Serial.printf("%s (len=%u): %s --> ", label, strlen(s), s);
  const unsigned char *p = (const unsigned char *)s;
  while (*p) {
    Serial.printf("%02X ", *p);
    p++;
  }
  Serial.println();
}

void removeBOM(char *s) {
  if (!s) {
    return;
  }
  if (strlen(s) < 3) {
    return;
  }

  if ((unsigned char)s[0] == 0xEF && (unsigned char)s[1] == 0xBB && (unsigned char)s[2] == 0xBF) {
    memmove(s, s + 3, strlen(s + 3) + 1);
  }
}

static void stripTransportSuffix(char *s) {
  if (!s) {
    return;
  }

  char *marker = strstr(s, "||");
  if (!marker) {
    return;
  }

  char *tail = marker + 2;
  while (*tail == ' ' || *tail == '\t') {
    tail++;
  }

  if (*tail == '\0') {
    while (marker > s && (marker[-1] == ' ' || marker[-1] == '\t')) {
      marker--;
    }
    *marker = '\0';
    return;
  }

  int  pipeCount = 0;
  bool validTailChars = true;
  bool hasAlphaNum = false;
  for (const char *p = tail; *p; ++p) {
    const unsigned char c = static_cast<unsigned char>(*p);
    if (c == '|') {
      pipeCount++;
      continue;
    }
    if (isalnum(c)) {
      hasAlphaNum = true;
      continue;
    }
    if (c == '_' || c == '-' || c == ' ' || c == '\t') {
      continue;
    }
    validTailChars = false;
    break;
  }

  // Typical suffix from some streams: "|| 1|PLEV02B|F6|45"
  if (validTailChars && hasAlphaNum && pipeCount >= 2) {
    while (marker > s && (marker[-1] == ' ' || marker[-1] == '\t')) {
      marker--;
    }
    *marker = '\0';
  }
}

bool cleanMeta(const char *src, char *dst, size_t dstSize) {
  if (!src || !dst || dstSize == 0) {
    return false;
  }
  // bemásoljuk lokális bufferbe
  strlcpy(dst, src, dstSize);
  // BOM eltávolítás
  removeBOM(dst);
  // UTF-8 takarítás
  _utf8_clean(dst);
  // különböző aposztrofok és idézőjelek simára cserélése
  normalizeText(dst);
  // Egyes stream-ek technikai kódokat fűznek a title végére ("|| ...").
  stripTransportSuffix(dst);
  // csak ellenőrzés (nem módosít):
  if (!printable(dst)) {
    return false;
  }
  return true;
}

void normalizeText(char *s) {
  if (!s) return;

  std::string str = s;
  // Az "okos" aposztrof (utf-8: E2 80 99) cseréje simára
  size_t pos;
  while ((pos = str.find("\xE2\x80\x99")) != std::string::npos) {
    str.replace(pos, 3, "'"); 
  }

  // Opcionálisan a többi gyakori "négyzetet okozó" karakter cseréje:
  while ((pos = str.find("\xE2\x80\x93")) != std::string::npos) str.replace(pos, 3, "-"); // gondolatjel
  while ((pos = str.find("\xE2\x80\x9C")) != std::string::npos) str.replace(pos, 3, "\""); // nyitó idézőjel
  while ((pos = str.find("\xE2\x80\x9D")) != std::string::npos) str.replace(pos, 3, "\""); // záró idézőjel

  strcpy(s, str.c_str());
}

void _utf8_clean(char *s) {
  char *in = s;
  char *out = s;
  while (*in) {
    unsigned char c = (unsigned char)*in;
    // --- ZERO-WIDTH karakterek kiszűrése ---
    if (c == 0xE2 && (unsigned char)in[1] == 0x80 && ((unsigned char)in[2] == 0x8B || (unsigned char)in[2] == 0x8C || (unsigned char)in[2] == 0x8D)) {
      in += 3;
      continue;
    }
    // Soft hyphen
    if (c == 0xC2 && (unsigned char)in[1] == 0xAD) {
      in += 2;
      continue;
    }
    // --- MINDEN UTF-8 maradjon érintetlen ---
    // Csak másoljuk byte-onként
    *out++ = *in++;
  }
  *out = '\0';
}
