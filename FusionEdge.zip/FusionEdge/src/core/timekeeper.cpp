#include "options.h"
#include "Arduino.h"
#include "timekeeper.h"
#include "config.h"
#include "network.h"
#include "display.h"
#include "player.h"
#include "netserver.h"
#include "rtcsupport.h"
#include "../displays/tools/language.h"
#include "../pluginsManager/pluginsManager.h"
#ifdef USE_NEXTION
#    include "../displays/nextion.h"
#endif
#if DSP_MODEL == DSP_DUMMY
#    define DUMMYDISPLAY
#endif

#ifndef RSSI_DISPLAY_HYSTERESIS_DB
#    define RSSI_DISPLAY_HYSTERESIS_DB 3
#endif
#ifndef RSSI_DISPLAY_FORCE_UPDATE_MS
#    define RSSI_DISPLAY_FORCE_UPDATE_MS 30000UL
#endif
#ifndef AXS_RSSI_AUDIOINFO_REDRAW
#    if DSP_MODEL == DSP_AXS15231B
#        define AXS_RSSI_AUDIOINFO_REDRAW 1
#    else
#        define AXS_RSSI_AUDIOINFO_REDRAW 1
#    endif
#endif
#ifndef AXS_RSSI_POLL_INTERVAL_MS
#    if DSP_MODEL == DSP_AXS15231B
#        define AXS_RSSI_POLL_INTERVAL_MS 2000UL
#    else
#        define AXS_RSSI_POLL_INTERVAL_MS 2000UL
#    endif
#endif
#if RTCSUPPORTED
// #define TIME_SYNC_INTERVAL  24*60*60*1000
#else
#endif

static uint32_t getTimeSyncIntervalMs() {
#if RTCSUPPORTED
    uint16_t hours = config.store.timeSyncIntervalRTC;
    if (hours == 0) { hours = 1; }
    return static_cast<uint32_t>(hours) * 60UL * 60UL * 1000UL;
#else
    uint16_t minutes = config.store.timeSyncInterval;
    if (minutes == 0) { minutes = 1; }
    return static_cast<uint32_t>(minutes) * 60UL * 1000UL;
#endif
}

static uint32_t getWeatherSyncIntervalMs() {
    uint16_t minutes = config.store.weatherSyncInterval;
    if (minutes == 0) { minutes = 1; }
    return static_cast<uint32_t>(minutes) * 60UL * 1000UL;
}

#define SYNC_STACK_SIZE    1024 * 4
#define SYNC_TASK_CORE     0 // "core_set" 0
#define SYNC_TASK_PRIORITY 3 // "task_prioritas" 3
#define WEATHER_STRING_L   254
/*
#ifdef HEAP_DBG
void printHeapFragmentationInfo(const char* title) {
    size_t freeHeap = heap_caps_get_free_size(MALLOC_CAP_DEFAULT);
    size_t largestBlock = heap_caps_get_largest_free_block(MALLOC_CAP_DEFAULT);
    float  fragmentation = 100.0 * (1.0 - ((float)largestBlock / (float)freeHeap));
    Serial.printf("\n****** %s ******\n", title);
    Serial.printf("* Free heap: %u bytes\n", freeHeap);
    Serial.printf("* Largest free block: %u bytes\n", largestBlock);
    Serial.printf("* Fragmentation: %.2f%%\n", fragmentation);
    Serial.printf("*************************************\n\n");
}
#    define HEAP_INFO() printHeapFragmentationInfo(__PRETTY_FUNCTION__)
#else
#    define HEAP_INFO()
#endif
*/
#ifdef HEAP_DBG

#    include <esp_heap_caps.h>
#    include <esp_system.h>

static float calcFragmentation(size_t freeBytes, size_t largestBlock) {
    if (freeBytes == 0) return 0.0f;
    return 100.0f * (1.0f - ((float)largestBlock / (float)freeBytes));
}

void printHeapFragmentationInfo(const char* title) {
    // Default heap
    size_t freeHeapDefault = heap_caps_get_free_size(MALLOC_CAP_DEFAULT);
    size_t largestDefault = heap_caps_get_largest_free_block(MALLOC_CAP_DEFAULT);
    float  fragDefault = calcFragmentation(freeHeapDefault, largestDefault);

    // Internal RAM
    size_t freeHeapInternal = heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
    size_t largestInternal = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL);
    float  fragInternal = calcFragmentation(freeHeapInternal, largestInternal);

    // DMA-képes belső RAM, ha érdekel sprite / kijelző műveleteknél
    size_t freeHeapDma = heap_caps_get_free_size(MALLOC_CAP_DMA);
    size_t largestDma = heap_caps_get_largest_free_block(MALLOC_CAP_DMA);
    float  fragDma = calcFragmentation(freeHeapDma, largestDma);

    // PSRAM
    size_t freeHeapPsram = 0;
    size_t largestPsram = 0;
    float  fragPsram = 0.0f;
    bool   hasPsram = psramFound();

    if (hasPsram) {
        freeHeapPsram = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
        largestPsram = heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM);
        fragPsram = calcFragmentation(freeHeapPsram, largestPsram);
    }

    Serial.printf("\n****** %s ******\n", title);

    Serial.printf("[DEFAULT]\n");
    Serial.printf("* Free heap:          %u bytes\n", (unsigned)freeHeapDefault);
    Serial.printf("* Largest free block: %u bytes\n", (unsigned)largestDefault);
    Serial.printf("* Fragmentation:      %.2f%%\n", fragDefault);

    Serial.printf("\n[INTERNAL]\n");
    Serial.printf("* Free heap:          %u bytes\n", (unsigned)freeHeapInternal);
    Serial.printf("* Largest free block: %u bytes\n", (unsigned)largestInternal);
    Serial.printf("* Fragmentation:      %.2f%%\n", fragInternal);

    Serial.printf("\n[DMA]\n");
    Serial.printf("* Free heap:          %u bytes\n", (unsigned)freeHeapDma);
    Serial.printf("* Largest free block: %u bytes\n", (unsigned)largestDma);
    Serial.printf("* Fragmentation:      %.2f%%\n", fragDma);

    Serial.printf("\n[PSRAM]\n");
    if (hasPsram) {
        Serial.printf("* PSRAM found:        yes\n");
        Serial.printf("* Free PSRAM heap:    %u bytes\n", (unsigned)freeHeapPsram);
        Serial.printf("* Largest free block: %u bytes\n", (unsigned)largestPsram);
        Serial.printf("* Fragmentation:      %.2f%%\n", fragPsram);
        Serial.printf("* ESP.getPsramSize(): %u bytes\n", (unsigned)ESP.getPsramSize());
        Serial.printf("* ESP.getFreePsram(): %u bytes\n", (unsigned)ESP.getFreePsram());
    } else {
        Serial.printf("* PSRAM found:        no\n");
    }

    Serial.printf("\n[ESP API]\n");
    Serial.printf("* ESP.getHeapSize():     %u bytes\n", (unsigned)ESP.getHeapSize());
    Serial.printf("* ESP.getFreeHeap():     %u bytes\n", (unsigned)ESP.getFreeHeap());
    Serial.printf("* ESP.getMaxAllocHeap(): %u bytes\n", (unsigned)ESP.getMaxAllocHeap());

    Serial.printf("*************************************\n\n");
}

#    define HEAP_INFO() printHeapFragmentationInfo(__PRETTY_FUNCTION__)

#else
#    define HEAP_INFO()
#endif

TimeKeeper timekeeper;

void _syncTask(void* pvParameters) {
    if (timekeeper.forceWeather && timekeeper.forceTimeSync) {
        timekeeper.timeTask();
        timekeeper.weatherTask();
    } else if (timekeeper.forceWeather) {
        timekeeper.weatherTask();
    } else if (timekeeper.forceTimeSync) {
        timekeeper.timeTask();
    }
    timekeeper.busy = false;
    vTaskDelete(NULL);
}

TimeKeeper::TimeKeeper() {
    busy = false;
    forceWeather = true;
    forceTimeSync = true;
    _returnPlayerTime = _doAfterTime = 0;
    weatherBuf    = NULL;
    weatherIcon[0] = '\0';
    tempC          = 0.0f;
#if (DSP_MODEL != DSP_DUMMY || defined(USE_NEXTION)) && !defined(HIDE_WEATHER)
    weatherBuf = (char*)malloc(sizeof(char) * WEATHER_STRING_L);
    memset(weatherBuf, 0, WEATHER_STRING_L);
#endif
}

bool TimeKeeper::loop0() { // core0 (display)
    if (network.status != CONNECTED) { return true; }
    uint32_t        currentTime = millis();
    static uint32_t _last05s = 0;
    static uint32_t _last1s = 0;
    static uint32_t _last2s = 0;
    static uint32_t _last5s = 0;
    if (currentTime - _last05s >= 500) { // 0,5 sec
        _last05s = currentTime;
        pm.on_ticker();
    }
    if (currentTime - _last1s >= 1000) { // 1sec
        _last1s = currentTime;

// #ifndef DUMMYDISPLAY
#if !defined(DUMMYDISPLAY) || defined(USE_NEXTION)
#    ifndef UPCLOCK_CORE1
        _upClock();
#    endif
#endif
    }
    if (currentTime - _last2s >= 2000) { // 2sec
        _last2s = currentTime;
    }
    if (currentTime - _last5s >= 5000) { // 5sec
        _last5s = currentTime;
        HEAP_INFO();
    }

    return true; // just in case
}

bool TimeKeeper::loop1() { // core1 (player)
    uint32_t        currentTime = millis();
    static uint32_t _last1s = 0;
    static uint32_t _last2s = 0;
    static uint32_t _lastStallCheck = 0;
    static uint32_t _stallSince = 0;
    static uint32_t _lastRestart = 0;
    static uint32_t _restartBackoffMs = 5000;
    static bool     _stallLogged = false;
    if (currentTime - _last1s >= 1000) { // 1sec
        _last1s = currentTime;
        //   pm.on_ticker();
#if !defined(DUMMYDISPLAY) || defined(USE_NEXTION)
#    ifdef UPCLOCK_CORE1
        _upClock();
#    endif
#endif
        _upScreensaver();
        _upSDPos();
        _returnPlayer();
        _doAfterWait();
    }
    if (currentTime - _last2s >= 2000) { // 2sec
        _last2s = currentTime;
        _upRSSI();
    }
    /*----- by Andrzej Jaroszuk -----*/
    /*----- Megállítja a lejátszást internet rádió módban, ha a lejátszási puffer elfogy. Utána  újraindítja a lejátszást. -----*/
    /*----- Stops playback in internet radio mode when the playback buffer runs out. Then restarts playback. -----*/
    if (currentTime - _lastStallCheck >= 1000) { // 1sec
        _lastStallCheck = currentTime;
        const bool eligible = config.store.stallWatchdog
                           && config.getMode() == PM_WEB
                           && network.status == CONNECTED
                           && !network.beginReconnect
                           && !player.lockOutput
                           && !config.isClockTTS
                           && player.wantsPlayback();

        if (eligible) {
            const bool audioRunning = player.isRunning();
            const uint32_t buffered = audioRunning ? player.inBufferFilled() : 0;
            const bool stalled = !audioRunning || buffered == 0;

            if (stalled) {
                if (_stallSince == 0) {
                    _stallSince = currentTime;
                    _stallLogged = false;
                }

                const uint32_t faultDelayMs = audioRunning ? 12000UL : 6000UL;
                if (!_stallLogged && currentTime - _stallSince >= faultDelayMs) {
                    log_w("##[STALL]# detected reason=%s station=%u backoff=%lu ms",
                          audioRunning ? "empty-buffer" : "audio-stopped",
                          (unsigned)config.lastStation(),
                          (unsigned long)_restartBackoffMs);
                    _stallLogged = true;
                }

                if (currentTime - _stallSince >= faultDelayMs
                    && currentTime - _lastRestart >= _restartBackoffMs
                    && player.readyForWebStation()) {
                    const uint16_t station = config.lastStation();
                    log_w("##[STALL]# restarting station=%u", (unsigned)station);
                    player.sendCommand({PR_STOP, 0});
                    player.sendCommand({PR_PLAY, station});
                    _lastRestart = currentTime;
                    _restartBackoffMs = min<uint32_t>(_restartBackoffMs * 2, 60000UL);
                    _stallSince = 0;
                    _stallLogged = false;
                }
            } else {
                _stallSince = 0;
                _lastRestart = 0;
                _restartBackoffMs = 5000;
                _stallLogged = false;
            }
        } else {
            _stallSince = 0;
            _stallLogged = false;
            if (!player.wantsPlayback() || !config.store.stallWatchdog) {
                _lastRestart = 0;
                _restartBackoffMs = 5000;
            }
        }
    }
#if defined(DUMMYDISPLAY) && !defined(USE_NEXTION)
    return true;
#endif
    // Sync weather & time
    static uint32_t lastWeatherTime = 0;
    if (currentTime - lastWeatherTime >= getWeatherSyncIntervalMs()) {
        lastWeatherTime = currentTime;
        forceWeather = true;
    }
    static uint32_t lastTimeTime = 0;
    if (currentTime - lastTimeTime >= getTimeSyncIntervalMs()) {
        lastTimeTime = currentTime;
        forceTimeSync = true;
    }
    if (!busy && (forceWeather || forceTimeSync) && network.status == CONNECTED) {
        busy = true;
        // config.setTimeConf();
        xTaskCreatePinnedToCore(_syncTask, "syncTask", SYNC_STACK_SIZE,
                                NULL,               // Params
                                SYNC_TASK_PRIORITY, // "task_prioritas"
                                NULL,               // Descriptor
                                SYNC_TASK_CORE      // "core_set"
        );
    }

    return true; // just in case
}

void TimeKeeper::waitAndReturnPlayer(uint8_t time_s) {
    _returnPlayerTime = millis() + time_s * 1000;
}

void TimeKeeper::_returnPlayer() {
    if (_returnPlayerTime > 0 && millis() >= _returnPlayerTime) {
        _returnPlayerTime = 0;
        if (display.mode() == STATIONS) {
            if (config.store.directChannelChange) {
                if (config.lastStation() != display.currentPlItem) {
                    display.putRequest(CLOSEPLAYLIST, display.currentPlItem); // STATION listaban vagyunk, akkor a kijelzőn lévő számra váltunk
                } else {
                    display.putRequest(NEWMODE, PLAYER);
                }
            } else {
                display.putRequest(NEWMODE, PLAYER);
            }
        } else if (display.mode() == VOL) { // hangerő
            display.putRequest(NEWMODE, PLAYER);
        }
    }
}

void TimeKeeper::waitAndDo(uint8_t time_s, void (*callback)()) {
    _doAfterTime = millis() + time_s * 1000;
    _aftercallback = callback;
}
void TimeKeeper::_doAfterWait() {
    if (_doAfterTime > 0 && millis() >= _doAfterTime) {
        _doAfterTime = 0;
        _aftercallback();
    }
}

void TimeKeeper::_upClock() {
#if RTCSUPPORTED
    if (config.isRTCFound()) {
        tm currentTime{};
        rtc.getTime(&currentTime);
        mktime(&currentTime);
        network_set_timeinfo(currentTime);
    }
#else
    tm currentTime{};
    network_get_timeinfo_snapshot(&currentTime);
    if (currentTime.tm_year > 100 || network.status == SDREADY) {
        currentTime.tm_sec++;
        mktime(&currentTime);
        network_set_timeinfo(currentTime);
    }
#endif
    if (display.ready()) { display.putRequest(CLOCK); }
}

void TimeKeeper::_upScreensaver() {
    if (!display.ready()) { return; }
    const bool playbackActive = config.isPlaybackActive();
    if (config.store.screensaverEnabled && display.mode() == PLAYER && (!playbackActive || config.store.volume == 0)) { // "PWR_AMP"
        config.screensaverTicks++;
        if (config.screensaverTicks > config.store.screensaverTimeout + SCREENSAVERSTARTUPDELAY) {
#if PWR_AMP != 255 // "PWR_AMP"
            digitalWrite(PWR_AMP, LOW);
#endif
            if (config.store.screensaverBlank) {
                display.putRequest(NEWMODE, SCREENBLANK);
            } else {
                display.putRequest(NEWMODE, SCREENSAVER);
            }
            config.screensaverTicks = SCREENSAVERSTARTUPDELAY;
        }
    }
    if (config.store.screensaverPlayingEnabled && display.mode() == PLAYER && playbackActive) {
        config.screensaverPlayingTicks++;
        if (config.screensaverPlayingTicks > config.store.screensaverPlayingTimeout + SCREENSAVERSTARTUPDELAY) {
            if (config.store.screensaverPlayingBlank) {
                display.putRequest(NEWMODE, SCREENBLANK);
            } else {
                display.putRequest(NEWMODE, SCREENSAVER);
            }
            config.screensaverPlayingTicks = SCREENSAVERSTARTUPDELAY;
        }
    }
}

#define RSSI_TESZT false
void TimeKeeper::_upRSSI() {
    static uint32_t lastRssiPollMs = 0;
    const uint32_t  rssiNow = millis();
    if (network.status == CONNECTED && (lastRssiPollMs == 0 || rssiNow - lastRssiPollMs >= AXS_RSSI_POLL_INTERVAL_MS)) {
        lastRssiPollMs = rssiNow;
#if (RSSI_TESZT)
        static int fakeRssi = -100;
        const int currentRssi = fakeRssi;
        fakeRssi += 10;
        if (fakeRssi > -10) fakeRssi = -100;
#else
        const int currentRssi = WiFi.RSSI();
#endif
        netserver.setRSSI(currentRssi);
        netserver.requestOnChangeNoWait(NRSSI, 0);

        if (display.ready()) {
            static int      lastDisplayRssi = 9999;
            static int8_t   lastDisplayStrength = -1;
            static uint32_t lastDisplayMs = 0;

            const uint32_t now = millis();
            const bool     firstUpdate = (lastDisplayRssi == 9999);
            const bool     forceUpdate = !firstUpdate && RSSI_DISPLAY_FORCE_UPDATE_MS > 0 && (now - lastDisplayMs >= RSSI_DISPLAY_FORCE_UPDATE_MS);
            bool           shouldUpdateDisplay = firstUpdate || forceUpdate;

            if (config.store.rssiAsText) {
                shouldUpdateDisplay = shouldUpdateDisplay || (abs(currentRssi - lastDisplayRssi) >= RSSI_DISPLAY_HYSTERESIS_DB);
            } else {
                int8_t strength = 0;
                if (currentRssi >= -55) strength = 4;
                else if (currentRssi >= -67) strength = 3;
                else if (currentRssi >= -75) strength = 2;
                else if (currentRssi >= -85) strength = 1;
                shouldUpdateDisplay = shouldUpdateDisplay || (strength != lastDisplayStrength);
                lastDisplayStrength = strength;
            }

            if (shouldUpdateDisplay || (AXS_RSSI_AUDIOINFO_REDRAW && config.store.audioinfo && player.isRunning())) {
                lastDisplayRssi = currentRssi;
                lastDisplayMs = now;
                display.putRequest(DSPRSSI, currentRssi);
            }
        }
    }
#ifdef USE_SD
    if (config.getMode() == PM_SDCARD && display.mode() != SDCHANGE) { player.sendCommandNoWait({PR_CHECKSD, 0}); }
#endif
}

void TimeKeeper::_upSDPos() {
    if (player.isRunning() && config.getMode() == PM_SDCARD) { netserver.requestOnChange(SDPOS, 0); }
}

void TimeKeeper::timeTask() {
    static uint8_t tsFailCnt = 0;
    config.waitConnection();
    tm prevTime{};
    network_get_timeinfo_snapshot(&prevTime);
    tm syncedTime{};
    if (getLocalTime(&syncedTime)) {
        tsFailCnt = 0;
        forceTimeSync = false;
        mktime(&syncedTime);

        const bool minuteOrDateChanged = (prevTime.tm_min != syncedTime.tm_min) || (prevTime.tm_hour != syncedTime.tm_hour) || (prevTime.tm_mday != syncedTime.tm_mday) ||
                                         (prevTime.tm_mon != syncedTime.tm_mon) || (prevTime.tm_year != syncedTime.tm_year);

        network_set_timeinfo(syncedTime);
        if (minuteOrDateChanged) {
            display.putRequest(CLOCK, 1);
        } else {
            display.putRequest(CLOCK);
        }
        network.requestTimeSync();
#if RTCSUPPORTED
        if (config.isRTCFound()) { rtc.setTime(&syncedTime); }
#endif
    } else {
        if (tsFailCnt < 4) {
            forceTimeSync = true;
            tsFailCnt++;
        } else {
            forceTimeSync = false;
            tsFailCnt = 0;
        }
    }
}
void TimeKeeper::weatherTask() {
    forceWeather = false;
    if (!weatherBuf || strlen(config.store.weatherkey) == 0 || !config.store.showweather) { return; }
    _getWeather();
}

bool _getWeather() {
#if (DSP_MODEL != DSP_DUMMY || defined(USE_NEXTION)) && !defined(HIDE_WEATHER)
    static AsyncClient* weatherClient = NULL;
    static const char*  host = "api.openweathermap.org";
    if (weatherClient) { return false; }
    weatherClient = new AsyncClient();
    if (!weatherClient) { return false; }

    weatherClient->onError(
        [](void* arg, AsyncClient* client, int error) {
            Serial.println("##WEATHER###: connection error");
            weatherClient = NULL;
            delete client;
        },
        NULL);

    weatherClient->onConnect(
        [](void* arg, AsyncClient* client) {
            weatherClient->onError(NULL, NULL);
            weatherClient->onDisconnect(
                [](void* arg, AsyncClient* c) {
                    weatherClient = NULL;
                    delete c;
                },
                NULL);

            char httpget[250] = {0};
            sprintf(httpget, "GET /data/2.5/weather?lat=%s&lon=%s&units=%s&lang=%s&appid=%s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n", config.store.weatherlat, config.store.weatherlon,
                    LANG::weatherUnits, LANG::weatherLang, config.store.weatherkey, host);
            client->write(httpget);

            client->onData(
                [](void* arg, AsyncClient* c, void* data, size_t len) {
                    uint8_t*    d = (uint8_t*)data;
                    const char* bodyStart = strstr((const char*)d, "\r\n\r\n");
                    if (bodyStart != NULL) {
                        bodyStart += 4;
                        size_t bodyLen = len - (bodyStart - (const char*)d);
                        char   line[bodyLen + 1];
                        memcpy(line, bodyStart, bodyLen);
                        line[bodyLen] = '\0';
                        /* parse it */
                        char* cursor;
                        char  desc[120], icon[5];
                        float tempf, tempfl, wind_speed;
                        int   hum, press, wind_deg;
                        bool  result = true;

                        cursor = strstr(line, "\"description\":\"");
                        if (cursor) {
                            sscanf(cursor, "\"description\":\"%119[^\"]", desc);
                        } else {
                            Serial.println("##WEATHER###: description not found !");
                            result = false;
                        }
                        cursor = strstr(line, "\"icon\":\"");
                        if (cursor) {
                            sscanf(cursor, "\"icon\":\"%4[^\"]", icon);
                            strlcpy(timekeeper.weatherIcon, icon, sizeof(timekeeper.weatherIcon));
                        } else {
                            Serial.println("##WEATHER###: icon not found !");
                            result = false;
                        }
                        cursor = strstr(line, "\"temp\":");
                        if (cursor) {
                            sscanf(cursor, "\"temp\":%f", &tempf);
                            timekeeper.tempC = tempf;
                        } else {
                            Serial.println("##WEATHER###: temp not found !");
                            result = false;
                        }
                        cursor = strstr(line, "\"pressure\":");
                        if (cursor) {
                            sscanf(cursor, "\"pressure\":%d", &press);
                        } else {
                            Serial.println("##WEATHER###: pressure not found !");
                            result = false;
                        }
                        cursor = strstr(line, "\"humidity\":");
                        if (cursor) {
                            sscanf(cursor, "\"humidity\":%d", &hum);
                        } else {
                            Serial.println("##WEATHER###: humidity not found !");
                            result = false;
                        }
                        cursor = strstr(line, "\"feels_like\":");
                        if (cursor) {
                            sscanf(cursor, "\"feels_like\":%f", &tempfl);
                        } else {
                            Serial.println("##WEATHER###: feels_like not found !");
                            result = false;
                        }
                        // cursor = strstr(line, "\"grnd_level\":");
                        // if (cursor) { sscanf(cursor, "\"grnd_level\":%d", &press); }
                        cursor = strstr(line, "\"speed\":");
                        if (cursor) {
                            sscanf(cursor, "\"speed\":%f", &wind_speed);
                        } else {
                            Serial.println("##WEATHER###: wind speed not found !");
                            result = false;
                        }
                        cursor = strstr(line, "\"deg\":");
                        if (cursor) {
                            sscanf(cursor, "\"deg\":%d", &wind_deg);
                        } else {
                            Serial.println("##WEATHER###: wind deg not found !");
                            result = false;
                        }

                        if (!result) { return; }

                        const float press_corr = (float)press;
#    ifdef IMPERIALUNIT
                        const float press_inHg = press_corr * 0.02953f;
                        // OpenWeatherMap already returns mph when units=imperial.
                        const float wind_mph = wind_speed;
#    else
                        const int   press_hPa = (int)lroundf(press_corr);
                        const float wind_km = wind_speed * 3.6f;
#    endif

#    ifdef USE_NEXTION
                        nextion.putcmdf("press_txt.txt=\"%dmm\"", press);
                        nextion.putcmdf("hum_txt.txt=\"%d%%\"", hum);
                        char cmd[30];
                        snprintf(cmd, sizeof(cmd) - 1, "temp_txt.txt=\"%.1f\"", tempf);
                        nextion.putcmd(cmd);
                        int iconofset;
                        if (strstr(icon, "01") != NULL)
                            iconofset = 0;
                        else if (strstr(icon, "02") != NULL)
                            iconofset = 1;
                        else if (strstr(icon, "03") != NULL)
                            iconofset = 2;
                        else if (strstr(icon, "04") != NULL)
                            iconofset = 3;
                        else if (strstr(icon, "09") != NULL)
                            iconofset = 4;
                        else if (strstr(icon, "10") != NULL)
                            iconofset = 5;
                        else if (strstr(icon, "11") != NULL)
                            iconofset = 6;
                        else if (strstr(icon, "13") != NULL)
                            iconofset = 7;
                        else if (strstr(icon, "50") != NULL)
                            iconofset = 8;
                        else
                            iconofset = 9;
                        nextion.putcmd("cond_img.pic", 50 + iconofset);
                        nextion.weatherVisible(1);
#    endif

                        Serial.printf("##WEATHER###: description:%s temp:%.1f pressure:%d hPa humidity:%d%% wind:%.1f deg:%d\n",
                                      desc, tempf, press, hum, wind_speed, wind_deg);
                        uint8_t wind_idx = (uint8_t)(((float)(wind_deg % 360) + 11.25f) / 22.5f);
                        if (wind_idx > 15) { wind_idx = 0; }

                        PGM_P wdirP = (const char*)pgm_read_ptr(&LANG::getWindTable()[wind_idx]);

            if (config.store.shortWeather) {

              // SHORT:
              // "%d hPa \007 %d%% RH \007 %.1f km/h [%s]"
              snprintf_P(
                timekeeper.weatherBuf,
                WEATHER_STRING_L,
                (PGM_P)LANG::getWeatherFmt(),
              #ifdef IMPERIALUNIT
                press_inHg,     // float
              #else
                press_hPa,      // int
              #endif
                hum,
              #ifdef IMPERIALUNIT
                wind_mph,
              #else
                wind_km,
              #endif
                wdirP
              );

            } else {

              // LONG:
            #if EXT_WEATHER
              snprintf_P(
                timekeeper.weatherBuf,
                WEATHER_STRING_L,
                (PGM_P)LANG::getWeatherFmt(),
                desc,
                tempf,
                tempfl,
              #ifdef IMPERIALUNIT
                press_inHg,     // float
              #else
                press_hPa,      // int
              #endif
                hum,
              #ifdef IMPERIALUNIT
                wind_mph,
              #else
                wind_km,
              #endif
                wdirP
              );
            #else
              snprintf_P(
                timekeeper.weatherBuf,
                WEATHER_STRING_L,
                (PGM_P)LANG::getWeatherFmt(),
               desc,
                tempf,
              #ifdef IMPERIALUNIT
                press_inHg,     // float
              #else
                press_hPa,      // int
              #endif
                hum
              );
            #endif
            }

            display.putRequest(NEWWEATHER);
          } else {
            Serial.println("##WEATHER###: weather not found !");
                    }
                },
                NULL); // <-- client->onData
        },
        NULL); // <-- weatherClient->onConnect
    config.waitConnection();
    if (!weatherClient->connect(host, 80)) {
        Serial.println("##WEATHER###: connection failed");
        AsyncClient* client = weatherClient;
        weatherClient = NULL;
        delete client;
    }

    return true;
#endif // if (DSP_MODEL!=DSP_DUMMY || defined(USE_NEXTION)) && !defined(HIDE_WEATHER)
    return false;
}

//******************
